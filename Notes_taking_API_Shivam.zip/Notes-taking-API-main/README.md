API Endpoints:
• Create Note: Endpoint to add a new note to the database.
• Retrieve Notes: Endpoint to get a list of all notes, with an option to retrieve a single note by its ID.
• Update Note: Endpoint to update the content of an existing note.
• Delete Note: Endpoint to delete a note from the database.
